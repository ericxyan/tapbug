window.onload = function load() {
	// Bug constructor
	function Bug() {
		this.counter = 0;
		this.size = 10;
		this.live = true;
		this.x = this.size + Math.random() * (canvas.width - this.size);
		this.y = 0;
		this.target = new Target();
		this.search();
		this.type = 0;
		this.speed = 0;
		this.rad = 0;
		this.score = 0;
		this.alpha = 1;
		this.color = "rgb(255,0,0)";
		this.defColor(Math.random());

	}

	// Bug function to generate bug color
	Bug.prototype.defColor = function(num) {
		// Orange
		if (num >= 0.6 && num <= 1) {
			this.type = 0;
			this.speed = (level == 1) ? 60 / 60 : 80 / 60;
			this.score = 1;
			this.color = "rgba(255, 100, 0, ";
		}
		// Red
		else if (num >= 0.3 && num < 0.6) {
			this.type = 1;
			this.speed = (level == 1) ? 75 / 60 : 100 / 60;
			this.score = 3;
			this.color = "rgba(255, 0, 0, ";

		}
		// Black
		else if (num >= 0 && num < 0.3) {
			this.type = 2;
			this.speed = (level == 1) ? 150 / 60 : 200 / 60;
			this.score = 5;
			this.color = "rgba(0, 0, 0, ";
		}
	};

	// Bug function to search for the nearest food.
	Bug.prototype.search = function() {
		var dx = 0;
		var dy = 0;
		var dst = 0;

		for (var i in foods) {
			dx = foods[i].x - this.x;
			dy = foods[i].y - this.y;
			dst = Math.sqrt(dx * dx + dy * dy);

			if (dst < this.target.dst) {
				this.target.x = foods[i].x;
				this.target.y = foods[i].y;
				this.target.dst = dst;
				this.target.cos = (this.target.x - this.x) / this.target.dst;
				this.target.sin = (this.target.y - this.y) / this.target.dst;
				this.target.index = i;
				this.target.dx = dx;
				this.target.dy = dy;
			}
		}

		if (this.target.dx > 0 && this.target.dy > 0)
			this.rad = Math.asin(this.target.sin);
		else if (this.target.dx < 0 && this.target.dy > 0)
			this.rad = Math.PI - Math.asin(this.target.sin);
		else if (this.target.dx < 0 && this.target.dy < 0)
			this.rad = Math.atan2(this.target.dy / this.target.dx) + Math.PI;
		else if (this.target.dx > 0 && this.target.dy < 0)
			this.rad = -Math.acos(this.target.cos);
	};

	// Bug function to update position
	Bug.prototype.update = function() {
		// Check eat
		var dx = this.x - this.target.x;
		var dy = this.y - this.target.y;
		if (Math.sqrt(dx * dx + dy * dy) < Math.sqrt(foodSize * foodSize)) {
			// Delete food
			foods.splice(this.target.index, 1);

			// Search for next target
			this.target = new Target();
			this.search();
		}
		this.x += this.speed * this.target.cos;
		this.y += this.speed * this.target.sin;
	};

	// Bug function to render
	Bug.prototype.render = function() {
		ctx.fillStyle = this.color;
		ctx.fillStyle = this.color + this.alpha + ")";
		ctx.beginPath();
		ctx.ellipse(this.x, this.y, 20, 5, this.rad, 0, Math.PI * 2);
		ctx.closePath();
		ctx.fill();

	};
	// Target constructor
	function Target(x, y) {
		this.x = 0;
		this.y = 0;
		this.dx = 0;
		this.dy = 0;
		this.cos = 0;
		this.sin = 0;
		this.dst = canvas.width + canvas.height;
	};

	// Food constructor
	function Food() {
		this.x = foodSize + Math.random() * (canvas.width - 2 * foodSize);
		this.y = Math.random() * (canvas.height / 2) + canvas.height / 2 - foodSize;
		this.size = 15;
		this.color = "rgb(0, 255, 255)";
	};

	// Food function to render
	Food.prototype.render = function() {
		ctx.fillStyle = this.color;
		ctx.beginPath();
		ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
		ctx.closePath();
		ctx.fill();
	};

	// Initialize food array
	function createFoods(num) {
		for (var i = 0; i < num; i++) {
			foods.push(new Food());
		};
	}

	// Click handler function
	function getPosition(e) {
		var x = e.x;
		var y = e.y;
		var dx = 0;
		var dy = 0;
		var dst = 0;

		x -= canvas.offsetLeft;
		y -= canvas.offsetTop;

		// Check kill
		if (state == "play") {

			for (var i = 0; i < bugs.length; i++) {
				dx = bugs[i].x - x;
				dy = bugs[i].y - y;
				dst = Math.sqrt(dx * dx + dy * dy);
				//alert("x: " + x + "y: " + y + " dst: " + dst + "counter: " + bugs[i].counter);
				if (dst < clickRadius) {
					// Update score
					score += bugs[i].score;
					bugs[i].score = 0;
					document.getElementById("score").innerHTML = "Score: " + score;
					// Kill bug
					bugs[i].live = false;
				}
			}
		}
	}

	// Game state
	function updateGame() {
		counter++;
		// Game over: lose all foods
		if (foods.length == 0) {
			state = "over";
			document.getElementById("state").innerHTML = state;
		}

		// Win: time = 0
		if (time == 0) {
			state = "win";
			document.getElementById("state").innerHTML = state;
		}
		// time counter
		if (counter % 60 == 0) {
			time--;
			document.getElementById("counter").innerHTML = time + " sec";
		}

		// born new bug counter
		if (counter % (60 * rdm) == 0) {
			rdm = Math.round(Math.random() * 2 + 1);
			counter = 0;
			bugs.push(new Bug());
		}
	}

	// Game loop
	function loop() {

		ctx.clearRect(0, 0, canvas.width, canvas.height);

		// Draw object
		for (var j in bugs) {

			if (bugs[j].live) {
				bugs[j].search();
				bugs[j].update();
			} else {
				// Fade out
				bugs[j].counter++;
				bugs[j].alpha = 1 - bugs[j].counter / fadeTime;
				if (bugs[j].counter == fadeTime)
					bugs.splice(bugs[j], 1);
			}

			bugs[j].render();
		}
		for (var i in foods) {
			foods[i].render();
		};
		// update game state
		updateGame();
		// Check over;
		if (state == "over") {
			document.getElementById("state").innerHTML = state;
			window.cancelAnimationFrame(frame);
			if (score > localStorage.getItem("score"))
				localStorage.setItem("score", score);
			var restart = confirm("Game Over!\n" + "Your score: " + score + "!\n New Game?");
			if (!restart) {
				document.location.href = "start.html";
			} else {
				init();
			}
		} else if (state == "win") {
			// Record new level record.
			if (level + 1 > localStorage.getItem("levelRecord"))
				localStorage.setItem("levelRecord", level + 1);
			if (level < 2) {
				var next = confirm("You Win!\n" + "Next Level?");
				if (next) {
					init();
					level++;
					time = TIME;
					state = "play";
					document.getElementById("currentLevel").innerHTML = "Level: " + level;
				} else {
					document.location.href = "start.html";
				}
			} else {
				alert("You Finished the Game!");
				document.location.href = "start.html";
			}

		}
		// update frame
		frame = window.requestAnimationFrame(loop);
	}

	// Initialize game
	function init() {
		window.location.reload(true);
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		time = TIME;
		counter = 0;
		score = 0;
		state = "play";
		rdm = Math.round(Math.random() * 2 + 1);
		bugs = [];
		foods = [];
		createFoods(5);
		bugs = [new Bug()];

		document.getElementById("debug").innerHTML = "local level: " + localStorage.getItem("level");
		document.getElementById("state").innerHTML = state;
		document.getElementById("score").innerHTML = "Score: " + score;
		document.getElementById("currentLevel").innerHTML = "Level: " + level;
	}

	// Get canvas
	var canvas = document.getElementById("board");
	var btn = document.getElementById("state");
	var ctx = canvas.getContext("2d");

	// Define parameters
	var TIME = 60;
	var time = TIME;
	var clickRadius = 30;
	var state = "play";
	var foodSize = 20;
	var level = localStorage.getItem("level");
	var score = 0;
	var fadeTime = 120;
	var rdm = Math.round(Math.random() * 2 + 1);
	// Create food array
	var foods = [];
	createFoods(5);

	// Create bug array
	var bugs = [new Bug()];

	// Counter variables
	var frame;
	var counter = 0;

	loop();

	btn.addEventListener('click', function changeState() {
		if (state == "pause") {
			state = "play";
			loop();
		} else if (state == "play") {
			state = "pause";
			window.cancelAnimationFrame(frame);
		}

		document.getElementById("state").innerHTML = state;
		document.getElementById("debug").innerHTML = state;
	}, false);

	canvas.addEventListener("mousedown", getPosition, false);
	document.getElementById("debug").innerHTML = "local level: " + localStorage.getItem("level");
	document.getElementById("state").innerHTML = state;
	document.getElementById("currentLevel").innerHTML = "Level: " + level;
};

